package com.maib06.geminilivelauncher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Gemini Live Launcher"
            textSize = 22f
            gravity = Gravity.CENTER
        }

        val description = TextView(this).apply {
            text = "This helper asks Android to open your default digital assistant. Set Google/Gemini as the default assistant first."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }

        val launch = Button(this).apply {
            text = "Open Gemini Assistant"
            setOnClickListener { openAssistant() }
        }

        layout.addView(title, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(description, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(launch, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(layout)
    }

    private fun openAssistant() {
        try {
            // Uses Android's currently selected default digital assistant.
            startActivity(Intent(Intent.ACTION_ASSIST))
        } catch (_: ActivityNotFoundException) {
            // Fallback: open the Google app if the ROM has no ACTION_ASSIST handler.
            val googleIntent = packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
            if (googleIntent != null) {
                startActivity(googleIntent)
            } else {
                android.widget.Toast.makeText(
                    this,
                    "No assistant or Google app launch activity was found.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
