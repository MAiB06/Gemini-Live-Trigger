plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.maib06.geminilivelauncher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.maib06.geminilivelauncher"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
