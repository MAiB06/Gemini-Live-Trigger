package com.maib06.geminilive

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tiny settings store plus an on-device log you can read in the app (no PC needed). */
object Prefs {
    const val MODE_VOICE = "voice"     // Live, then send it to the background (voice only)
    const val MODE_FRONT = "front"     // Live, stay in front
    const val MODE_OVERLAY = "overlay" // plain assistant overlay, you tap the waveform

    val ALL_MODES = setOf(MODE_VOICE, MODE_FRONT, MODE_OVERLAY)

    private const val FILE = "settings"
    private const val KEY_MODE = "mode"
    private const val KEY_LOG = "log"
    private const val MAX_LOG_LINES = 60
    private const val TAG = "GeminiLive"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun mode(ctx: Context): String {
        val saved = prefs(ctx).getString(KEY_MODE, MODE_VOICE) ?: MODE_VOICE
        return if (saved in ALL_MODES) saved else MODE_VOICE
    }

    fun setMode(ctx: Context, mode: String) {
        prefs(ctx).edit().putString(KEY_MODE, mode).apply()
    }

    fun log(ctx: Context, message: String) {
        Log.i(TAG, message)
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val old = prefs(ctx).getString(KEY_LOG, "") ?: ""
        val lines = (old.split("\n").filter { it.isNotBlank() } + "$stamp  $message")
            .takeLast(MAX_LOG_LINES)
        prefs(ctx).edit().putString(KEY_LOG, lines.joinToString("\n")).apply()
    }

    fun readLog(ctx: Context): String = prefs(ctx).getString(KEY_LOG, "") ?: ""

    fun clearLog(ctx: Context) {
        prefs(ctx).edit().remove(KEY_LOG).apply()
    }
}
