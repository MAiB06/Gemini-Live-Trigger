package com.maib06.geminilive

import android.app.Activity
import android.os.Bundle

/**
 * Invisible activity. Key Mapper (or a launcher shortcut) starts this; it runs the launch
 * logic and closes itself. Optional extra "mode": voice | front | overlay.
 */
class TriggerActivity : Activity() {

    private var launcher: GeminiLauncher? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val requested = intent?.getStringExtra(EXTRA_MODE)
        val mode = if (requested != null && requested in Prefs.ALL_MODES) requested else Prefs.mode(this)
        Prefs.log(this, "--- Trigger pressed (mode=$mode) ---")

        val l = GeminiLauncher(this)
        launcher = l
        l.launch(mode) {
            if (!isFinishing) finish()
        }
    }

    override fun onDestroy() {
        launcher?.release()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_MODE = "mode"
    }
}
