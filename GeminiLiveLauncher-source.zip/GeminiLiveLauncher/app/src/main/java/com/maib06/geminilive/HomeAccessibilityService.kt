package com.maib06.geminilive

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Does exactly one thing: lets this app press HOME reliably (works even where ROMs block
 * background activity starts). It ignores every accessibility event and cannot read the screen.
 */
class HomeAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Prefs.log(this, "Accessibility helper connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally ignored.
    }

    override fun onInterrupt() {
        // Nothing to interrupt.
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    companion object {
        @Volatile
        var instance: HomeAccessibilityService? = null
    }
}
