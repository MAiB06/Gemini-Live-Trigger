package com.maib06.geminilive

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Launch logic.
 *
 * IMPORTANT, read this before trusting it:
 * Google publishes NO official intent for "open Gemini Live". The route used here is an
 * UNDOCUMENTED, exported Gemini activity that other developers have observed working
 * (see README for sources). It opens Live with the camera on. To get voice-only Live we
 * then press HOME as soon as the microphone starts, which leaves Live running in the
 * background. Google can change or disable this at any time (it is also gated by a
 * server-side flag), and it has NOT been verified on a OnePlus CN ROM.
 */
class GeminiLauncher(private val context: Context) {

    private val handler = Handler(Looper.getMainLooper())
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var recordingCallback: AudioManager.AudioRecordingCallback? = null
    private var timeoutTask: Runnable? = null
    private var waiting = false

    fun launch(mode: String, onDone: () -> Unit) {
        when (mode) {
            Prefs.MODE_OVERLAY -> {
                openAssistantOverlay()
                onDone()
            }
            Prefs.MODE_FRONT -> {
                if (!startLiveShortcut()) openAssistantOverlay()
                onDone()
            }
            else -> launchVoiceOnly(onDone)
        }
    }

    /** Stop listening for the microphone. Safe to call many times. */
    fun release() = stopWaiting()

    private fun launchVoiceOnly(onDone: () -> Unit) {
        if (!googleAppHasCamera(context)) {
            log("Google app has no Camera permission, so Live would stop to ask for it. Leaving Live in front. Grant Camera to the Google app (README step 3).")
            if (!startLiveShortcut()) openAssistantOverlay()
            onDone()
            return
        }

        val baseline = audio.activeRecordingConfigurations.size
        val startedAt = SystemClock.elapsedRealtime()
        waiting = true

        val callback = object : AudioManager.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
                if (!waiting) return
                if ((configs?.size ?: 0) > baseline) {
                    stopWaiting()
                    val ms = SystemClock.elapsedRealtime() - startedAt
                    log("Microphone started after $ms ms. Sending Live to the background.")
                    goHome()
                    onDone()
                }
            }
        }
        recordingCallback = callback
        audio.registerAudioRecordingCallback(callback, handler)

        if (!startLiveShortcut()) {
            stopWaiting()
            openAssistantOverlay()
            onDone()
            return
        }

        val timeout = Runnable {
            if (waiting) {
                stopWaiting()
                log("No microphone start within $MIC_WAIT_MS ms. Leaving Live in front (first-use prompt? Live already running? slow start?).")
                onDone()
            }
        }
        timeoutTask = timeout
        handler.postDelayed(timeout, MIC_WAIT_MS)
    }

    private fun stopWaiting() {
        waiting = false
        recordingCallback?.let { runCatching { audio.unregisterAudioRecordingCallback(it) } }
        recordingCallback = null
        timeoutTask?.let { handler.removeCallbacks(it) }
        timeoutTask = null
    }

    /** Starts Gemini's exported shortcut activity. Returns true if Android accepted the start. */
    private fun startLiveShortcut(): Boolean {
        if (!isGeminiInstalled(context)) {
            log("Gemini app ($GEMINI_PKG) is not installed or not visible.")
            return false
        }
        val intent = liveShortcutIntent()
        if (context.packageManager.resolveActivity(intent, 0) == null) {
            log("Gemini's Live shortcut activity was not found. Update the Gemini app (needs a recent version) or it is disabled. Falling back to the assistant overlay.")
            return false
        }
        return try {
            context.startActivity(intent)
            log("Started Gemini's Live shortcut.")
            true
        } catch (e: Exception) {
            log("Starting the Live shortcut failed: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    /** Plain assistant overlay. This is NOT Live; you still tap the waveform icon. */
    private fun openAssistantOverlay() {
        for (action in listOf(Intent.ACTION_ASSIST, Intent.ACTION_VOICE_COMMAND)) {
            try {
                context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                log("Opened the assistant via $action. Tap the waveform (Live) icon yourself.")
                return
            } catch (e: Exception) {
                log("$action failed: ${e.javaClass.simpleName}")
            }
        }
        log("No assistant answered. Set Gemini as the default digital assistant in system settings.")
    }

    private fun goHome() {
        val helper = HomeAccessibilityService.instance
        if (helper != null) {
            val ok = helper.goHome()
            log("Pressed Home through the accessibility helper (accepted=$ok).")
            if (ok) return
        }
        try {
            val home = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.applicationContext.startActivity(home)
            log("Requested Home via startActivity. Some ROMs silently block this: enable the accessibility helper if Live stays in front.")
        } catch (e: Exception) {
            log("Going Home failed: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun log(message: String) = Prefs.log(context, message)

    companion object {
        const val GEMINI_PKG = "com.google.android.apps.bard"
        const val GOOGLE_APP_PKG = "com.google.android.googlequicksearchbox"
        const val LIVE_SHORTCUT_CLASS =
            "com.google.android.apps.bard.shellapp.VisualInterpreterShortcutActivity"

        private const val MIC_WAIT_MS = 5000L

        fun liveShortcutIntent(): Intent = Intent().apply {
            component = ComponentName(GEMINI_PKG, LIVE_SHORTCUT_CLASS)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        @Suppress("DEPRECATION")
        fun isGeminiInstalled(ctx: Context): Boolean = try {
            ctx.packageManager.getPackageInfo(GEMINI_PKG, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }

        /** Asks PackageManager (not Intent.resolveActivity, which says yes for any explicit component). */
        fun isLiveShortcutAvailable(ctx: Context): Boolean =
            ctx.packageManager.resolveActivity(liveShortcutIntent(), 0) != null

        fun googleAppHasCamera(ctx: Context): Boolean =
            ctx.packageManager.checkPermission(Manifest.permission.CAMERA, GOOGLE_APP_PKG) ==
                PackageManager.PERMISSION_GRANTED
    }
}
