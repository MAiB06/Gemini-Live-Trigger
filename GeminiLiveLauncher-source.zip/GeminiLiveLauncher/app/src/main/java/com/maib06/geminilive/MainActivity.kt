package com.maib06.geminilive

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Setup + status screen. Everything is built in code so the project needs no libraries. */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad * 2)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        // Android 15+ draws apps edge to edge; keep content clear of the system bars.
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(scroll)

        root.addView(label("Gemini Live Launcher", 22f, bold = true))
        root.addView(label("Trigger = open Gemini Live. Status and setup below.", 14f))

        statusView = label("", 13f, mono = true)
        statusView.setPadding(0, pad, 0, pad)
        root.addView(statusView)

        root.addView(label("What should the trigger do?", 16f, bold = true))
        val group = RadioGroup(this)
        val options = listOf(
            Prefs.MODE_VOICE to "Live, voice only (recommended). Opens Live, then sends it to the background.",
            Prefs.MODE_FRONT to "Live, stay in front (you see the camera view).",
            Prefs.MODE_OVERLAY to "Assistant overlay only. You tap the waveform yourself."
        )
        val current = Prefs.mode(this)
        for ((value, text) in options) {
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = text
            rb.tag = value
            rb.isChecked = (value == current)
            group.addView(rb)
        }
        group.setOnCheckedChangeListener { g, checkedId ->
            val picked = g.findViewById<RadioButton>(checkedId)
            if (picked != null) Prefs.setMode(this, picked.tag as String)
        }
        root.addView(group)

        root.addView(button("TEST NOW: launch Gemini Live") {
            startActivity(Intent(this, TriggerActivity::class.java))
        })
        root.addView(label("One-time setup", 16f, bold = true))
        root.addView(button("Step 1: this app's info (allow restricted settings, battery)") {
            openSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        root.addView(button("Step 2: turn on the accessibility helper") {
            openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Step 3: Google app permissions (Camera, Mic, Notifications)") {
            openSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${GeminiLauncher.GOOGLE_APP_PKG}")))
        })
        root.addView(button("Gemini app info") {
            openSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${GeminiLauncher.GEMINI_PKG}")))
        })
        root.addView(button("Refresh status") { refresh() })

        root.addView(label("Last launch log (screenshot this if something fails)", 16f, bold = true))
        logView = label("", 12f, mono = true)
        logView.setTextIsSelectable(true)
        root.addView(logView)
        root.addView(button("Clear log") {
            Prefs.clearLog(this)
            refresh()
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        fun mark(ok: Boolean) = if (ok) "[OK] " else "[!!] "

        val gemini = GeminiLauncher.isGeminiInstalled(this)
        val live = GeminiLauncher.isLiveShortcutAvailable(this)
        val camera = GeminiLauncher.googleAppHasCamera(this)
        val helper = isHelperEnabled()

        statusView.text = buildString {
            append(mark(gemini)).append("Gemini app installed\n")
            append(mark(live)).append("Gemini Live shortcut found\n")
            append(mark(camera)).append("Google app has Camera permission\n")
            append("      (needed for voice-only mode)\n")
            append(mark(helper)).append("Accessibility helper on\n")
            append("      (makes 'send Live to background' reliable)")
        }
        logView.text = Prefs.readLog(this).ifBlank { "(empty. Press TEST NOW.)" }
    }

    private fun isHelperEnabled(): Boolean {
        if (HomeAccessibilityService.instance != null) return true
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return enabled.contains(packageName) && enabled.contains("HomeAccessibilityService")
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Could not open that settings page on this ROM.", Toast.LENGTH_LONG).show()
        }
    }

    private fun label(text: String, sizeSp: Float, bold: Boolean = false, mono: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sizeSp
            if (mono) typeface = Typeface.MONOSPACE
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, (6 * resources.displayMetrics.density).toInt(), 0, (6 * resources.displayMetrics.density).toInt())
        }

    private fun button(text: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
        }
}
