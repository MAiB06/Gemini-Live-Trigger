plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.maib06.geminilive"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.maib06.geminilive"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // A fixed debug key (app/debug.keystore) means every CI build has the SAME
    // signature, so you can install new builds over the old one without
    // uninstalling (and without re-enabling the accessibility helper).
    signingConfigs {
        create("stableDebug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
            storeType = "pkcs12"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("stableDebug")
        }
    }

    // Java and Kotlin BOTH target 17 (fixes the "Inconsistent JVM-target" error).
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// No third-party dependencies on purpose: fewer things that can break the build.
