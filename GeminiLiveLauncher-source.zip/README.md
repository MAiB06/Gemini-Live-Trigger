# Gemini Live Launcher

A minimal Android helper app for China-ROM devices. It invokes Android's
`Intent.ACTION_ASSIST`, which should open the currently selected default
digital assistant (Google/Gemini, if configured by the ROM).

## Important limitation

This app does **not** call a documented public Gemini Live deep link. Google's
official Gemini widget offers a shortcut that opens directly to Gemini Live,
but Google does not document a public intent for that widget action.
Therefore this helper opens the assistant overlay; the user may still need to
tap the Live waveform button. It does not automate taps or bypass Android
permissions.

## Build with GitHub Actions

1. Create a new GitHub repository.
2. Upload all files from this project, preserving folders.
3. Push to the `main` branch, or run **Actions → Build Gemini Live Launcher APK → Run workflow**.
4. Open the completed workflow run.
5. Download the `GeminiLiveLauncher-debug` artifact and extract the APK.

## Use with Key Mapper

1. Install the APK.
2. Confirm Google/Gemini is selected as the default digital assistant in your
   OnePlus CN ROM, if that option is available.
3. In Key Mapper, record your physical button.
4. Add action **Open app** and select **Gemini Live Launcher**.
5. Press the button to test.

If `ACTION_ASSIST` is not handled by the CN ROM, the app falls back to opening
the Google app. That fallback is not Gemini Live.

## Technical basis

Android defines `Intent.ACTION_ASSIST` for invoking the current assistant.
Google documents a Gemini widget option that opens directly to Gemini Live,
but its internal widget intent is not a public API:
https://support.google.com/gemini/answer/16179553
